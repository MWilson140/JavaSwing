package PaymentMethod;

/**
 *
 * @author Mitchell Wilson
 * class for Storage of CreditCard information
 * extends PaymentMethod
 */
public class CreditCard extends PaymentMethod{
    private int creditCardNo;
    private int CSV;
    
    CreditCard()
    {}
    public CreditCard(int CCN, int csv)
    {
        creditCardNo = CCN;
        CSV = csv;
    }
    
    public int getCreditCardNo()
    {
        return creditCardNo;
    }
    
    public int getCSV()
    {
        return CSV;
    }
}
