package PaymentMethod;

/**
 *
 * @author Mitchell Wilson
 * Abstract class used for storing payment methods.
 */
abstract public class PaymentMethod {
    
}
