
package PaymentMethod;

/**
 *
 * @author Mitchell Wilson
 * class for Storage of Direct Debit information
 * extends PaymentMethod
 */
public class DirectDebit extends PaymentMethod{
    private int BSB;
    private int bankNo;
    
    public DirectDebit()
    {}
    
    public DirectDebit(int bsb, int BN)
    {
        BSB = bsb;
        bankNo = BN;
    }
    
    public int getBSB()
    {
        return BSB;
    }
    public int getBankNo()
    {
        return bankNo;
    }
    
}
