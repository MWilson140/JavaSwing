
package Customer;
import Supplement.*;
//import PaymentMethod.*;
import Magazine.*;

import java.util.ArrayList;

public class Customer 
{
    String name;
    String email;
    protected ArrayList <Supplement> intSups;
    public Customer()
    {
        intSups = new ArrayList<Supplement>();
    }
    public Customer (Customer c)
    {
        this.name = c.name;
        this.email = c.email;
        this.intSups = c.intSups;
    }
    public Customer(String s)
    {
        intSups = new ArrayList<Supplement>();
        email =s;
    }
    public Customer(String n, String e, ArrayList<Supplement> IS)
    {
        name = n;
        email = e;
        intSups = IS;
    }
    Customer (String n, String e)
    {
        name = n;
        email = e;
        intSups = new ArrayList<Supplement>();
    }
    public String getEmail()
    {
        return email;
    }
    public void addSupps(Supplement sup)
    {
        intSups.add(sup);
    }
    public void setEmail(String s)
    {
        email = s;
    }
    
    public String getName()
    {
        return name;
    }
    
    public ArrayList<Supplement> getIntSup()
    {
        return intSups;
    }
    public void sendEmail(Magazine mag)
    {
        System.out.println("*EMAIL TO SEND TO " + email + "");
        ArrayList<Supplement> overLap = new ArrayList<Supplement>();
        ArrayList<Supplement> magSup = mag.getSupp();
        //finds the overlap of interested sups and magazine supplements
        for (Supplement custSup : intSups)
        {
            for (Supplement tempMagSup : magSup)
            {
                if (tempMagSup.equals(custSup))
                {
                    overLap.add(tempMagSup);
                }
            }
        }
        //prints out the email to a customer
        System.out.print("hello free customer " + name + " this weeks magazie has been completed, upgrade to a paying customer to view. ");
        if (!overLap.isEmpty())
        {
            System.out.println("If you upgrade to a paying customer your supplements this week would be");
            for (Supplement printSup : overLap)
            {
                System.out.println(printSup.getName());
            }
        }
        System.out.println("thank you for your continued intetest\n");
        
    }
   
}
