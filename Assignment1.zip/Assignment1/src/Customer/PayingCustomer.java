package Customer;
import Magazine.*;
import java.util.ArrayList;
import java.util.*;
import PaymentMethod.*;
import Supplement.*;
//import PaymentMethod.*;


public class PayingCustomer extends Customer{
    private PaymentMethod paymentDetails;
    private ArrayList <Customer> AssocCustomers;
    private float amountDue;
    private ArrayList<String> srecipt;
  
    public PayingCustomer()
    {
        super();
        AssocCustomers = new ArrayList<Customer>();
        srecipt = new ArrayList<String>();
    }
    //assoc cust
    public PayingCustomer(String n, String e, ArrayList<Supplement> IS, 
            PaymentMethod PM, ArrayList<Customer> AC)
    {
        super(n, e, IS);
        paymentDetails = PM;
        AssocCustomers = AC;
        amountDue = 0;
         srecipt = new ArrayList<String>();
    }
    //no assoc cust
    public PayingCustomer(String n, String e, ArrayList<Supplement> IS, 
            PaymentMethod PM)
    {
        super(n, e, IS);
        paymentDetails = PM;
        AssocCustomers = new ArrayList<Customer>();
        amountDue = 0;
        srecipt = new ArrayList<String>();
    }
    
    public PayingCustomer(String s)
    {
        super(s);
        AssocCustomers = new ArrayList<Customer>();
         srecipt = new ArrayList<String>();
    }
    
    PayingCustomer(PaymentMethod PM)
    {
        paymentDetails = PM;
        amountDue = 0;
    }
     PayingCustomer(PaymentMethod PM, ArrayList<Customer> AC)
    {
        paymentDetails = PM;
        AssocCustomers = AC;
        amountDue = 0;
    }
     
    public ArrayList<String> getRecipt()
    {
        return srecipt;
    }
    public float getAmountDue()
    {
        return amountDue;
    }
    public void setAmountDue(float n)
    {
        amountDue = n;
    }
    
    public boolean removeAssoc(Customer cust)
    {
        return(AssocCustomers.remove(cust));
    }
    public ArrayList<Customer> getAssoc()
    {
        return AssocCustomers;
    }
    
    public PaymentMethod getPayment()
    {
        return paymentDetails;
    }
    
    public void addAssoc(Customer cust)
    {
        AssocCustomers.add(cust);
    }
    
    public ArrayList<Customer> getAssocCust()
    {
        return AssocCustomers;
    }

    public void updateAmountDue(Magazine mag)
    {
        ArrayList<Supplement> overLap = new ArrayList<Supplement>();
        ArrayList<Supplement> magSup = mag.getSupp();
        srecipt.add(mag.getName()); //add the magazine title to the recipt list
        amountDue += mag.getCost();  //adds the magazine cost to the amountDue
        for (Supplement custSup : intSups) //for each customer interested supplement
        {
            for (Supplement tempMagSup : magSup) //for each magazine supplement
            {
                if (tempMagSup.equals(custSup)) //if they are the same
                {
                    srecipt.add(tempMagSup.getName()); //add the supplement name to the recipt
                    amountDue += tempMagSup.getCost(); //adds the cost of the supplement to the recipt
                }
            }
        }
        if (!AssocCustomers.isEmpty()) //if the associate customer array is not empty
        {
            for (Customer assocCust : AssocCustomers) //for each associate customer
            {
                amountDue += mag.getCost(); //add another magazine cost to the amountDue
                srecipt.add(mag.getName()); //add another magazine name to the the recipt
                overLap = ((AssociateCustomer)assocCust).calcAmountDue(mag); //finds the overlap between the assoc customer and the magazine
                for (Supplement assocSup : overLap) //for each supplement
                {
                    amountDue += assocSup.getCost(); //increase the amountDue
                    srecipt.add(assocSup.getName()); //add the supplement to the recipt
                }     
            }
        }
    }

    public void sendRecipt()
    {
        System.out.println("*EMAIL TO " + email + "*");
        System.out.print("hello Paying customer " + name);
        if (amountDue > 0.0) //if they have an amount due
        {
            System.out.print(" the amount due this month is: ");
            System.out.println(amountDue);
            System.out.println("You're recipt is as follows:");
            Map<String, Integer> rMap = new HashMap<String, Integer>();
            //this section converts the arraylist to a map, containing the name of the item in the recipt and the count for a cleaner recipt
            for(String arrayElement : srecipt) 
            {
                if(!rMap.containsKey(arrayElement)) {
                rMap.put(arrayElement, 1);
                } else 
                {
                    int newCount = rMap.get(arrayElement) + 1;
                    rMap.put(arrayElement, newCount);
                }
            }     
            for (Map.Entry<String, Integer> info : rMap.entrySet()) //for each entry in the map, display the count and name
            {
                System.out.print(info.getValue() + " ");
                System.out.println(info.getKey());
                
            }
        }
        else
        {
            System.out.println(" nothing is due this month");
        }       
    }

    @Override public void sendEmail(Magazine mag)
    {
        System.out.println("*EMAIL TO SEND TO " + email + "*");
        ArrayList<Supplement> overLap = new ArrayList<Supplement>();
        ArrayList<Supplement> magSup = mag.getSupp();
        for (Supplement custSup : intSups) //for each supplement the customer is interested in
        {
            for (Supplement tempMagSup : magSup) //for each supplement the magazine has
            {
                if (tempMagSup.equals(custSup))
                {
                    overLap.add(tempMagSup);
                }
            }
        }
        System.out.print("hello paying customer "+ name +" this weeks magazie is ready. ");
        if (!overLap.isEmpty()) //for each supplement that the customer wants that the magazine has
        {
            System.out.println("Your supplements this week are as follows:");
            for (Supplement printSup : overLap)
            {
                System.out.println(printSup.getName());
            }
        }
        System.out.println("thank you for your continued support\n");
        
    }       
  }

