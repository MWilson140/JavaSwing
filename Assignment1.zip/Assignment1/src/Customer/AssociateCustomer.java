package Customer;
import Magazine.*;
import Supplement.*;
import java.util.ArrayList;

/**
 *
 * @author zealo
 */
public class AssociateCustomer extends Customer
{
    private Customer whoIsPaying;
    
    public AssociateCustomer()
    {
        super();
    }
    
    public AssociateCustomer(String s)
    {
        super(s);
    }
    
    public AssociateCustomer(String s, Customer c)
    {
        super(s);
        whoIsPaying = c;
    }
    public AssociateCustomer(String n, String e, ArrayList<Supplement> sup, Customer c)
    {
        super(n,e,sup);
        whoIsPaying = c;
             
    }
    
    
    public Customer getWhoIsPaying()
    {
        return whoIsPaying;
    }

    public ArrayList<Supplement> calcAmountDue(Magazine mag)
    {
        ArrayList<Supplement> overLap = new ArrayList<Supplement>();
        ArrayList<Supplement> magSup = mag.getSupp();
        for (Supplement custSup : intSups)
        {
            for (Supplement tempMagSup : magSup)
            {
                if (tempMagSup.equals(custSup))
                {
                    overLap.add(tempMagSup);
                }
            }   
        }
        return overLap;
    }

    @Override public void sendEmail(Magazine mag)
   {
        System.out.println("*EMAIL TO SEND TO " + email + "*");
        ArrayList<Supplement> overLap = new ArrayList<Supplement>();
        ArrayList<Supplement> magSup = mag.getSupp();
        for (Supplement custSup : intSups)
        {
            for (Supplement tempMagSup : magSup)
            {
                if (tempMagSup.equals(custSup))
                {
                    overLap.add(tempMagSup);
                }
            }
        }
        System.out.print("hello associate customer " + name +  " this weeks magazie is ready.");
        if (!overLap.isEmpty())
        {
            System.out.println("Your supplements this week are as follows:");
            for (Supplement printSup : overLap)
            {
                System.out.println(printSup.getName());
            }
        }
        System.out.println("thank you for your continued burden\n");
        
    }     
}
