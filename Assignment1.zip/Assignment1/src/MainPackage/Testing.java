package MainPackage;

import Supplement.*;
import Magazine.*;
import Customer.*;
import PaymentMethod.*;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public  class Testing {

    public static Supplement createSupp(String[] data)
    {
        Supplement s = new Supplement(data[1], Float.parseFloat(data[2]));
        return s;
    }

    public static Magazine createMag(String[] data, ArrayList<Supplement> supList)
    {
        ArrayList <Supplement> magSup = new ArrayList<Supplement>();
        for (int i = 2; i < data.length; i ++)
        {
            for (Supplement sup : supList)
            {
                if (sup.getName().equals(data[i]))
                {
                    magSup.add(sup);
                }
            }
        }
        Magazine m = new Magazine(data[1], Float.parseFloat(data[2]), magSup);
        return m;
    } 

    public static Customer createCust(String[] data, ArrayList<Supplement> supList)
    {
        ArrayList <Supplement> custSup = new ArrayList<Supplement>();
        for (int i = 2; i < data.length; i ++)
        {
            for (Supplement sup : supList)
            {
                if (sup.getName().equals(data[i]))
                {
                    custSup.add(sup);
                }
            }
        }
        Customer c = new Customer(data[1], data[2], custSup);
        return c;   
    }

    public static Customer createPCust(String[] data, ArrayList<Supplement> supList)
    {
        PaymentMethod pay = null;
        PayingCustomer c = null;
        if (data[1].equals("b"))
        {
            pay = new DirectDebit(Integer.parseInt(data[4]), Integer.parseInt(data[5]));
        }
        if (data[1].equals("c"))
        {
            pay = new CreditCard(Integer.parseInt(data[4]), Integer.parseInt(data[5]));
        }
        ArrayList <Supplement> custSup = new ArrayList<Supplement>();
        for (int i = 6; i < data.length; i ++)
        {
            for (Supplement sup : supList)
            {
                if (sup.getName().equals(data[i]))
                {
                    custSup.add(sup);
                }
            }
        }
            c = new PayingCustomer(data[2], data[3], custSup, pay);
            return c;
    }

    public static Customer createACust(String[] data, ArrayList<Supplement> supList, ArrayList<Customer> custList)
    {
        ArrayList <Supplement> custSup = new ArrayList<Supplement>();
        Customer payingCust = null;
        for (int i = 4; i < data.length; i ++)
        {
            for (Supplement sup : supList)
            {
                if (sup.getName().equals(data[i]))
                {
                    custSup.add(sup);
                }
            }
        }
        for (Customer pCust : custList)
        {
            if (pCust.getName().equals(data[3]))
            {
                payingCust = pCust;
            }
        } 
        AssociateCustomer c = new AssociateCustomer(data[1], data[2], custSup, payingCust);
        ((PayingCustomer)payingCust).addAssoc(c);
        return c;     
    }

    public static void infoDump(ArrayList<Supplement> supList, ArrayList<Magazine> magList, ArrayList<Customer> custList)
    {
        System.out.println("\n\n*****INFO DUMP*****");
        PaymentMethod pay = null;
        System.out.println("\nSUPPLEMENTS");
        for (Supplement sup : supList)
        {
            System.out.println(sup.getName() + " " + sup.getCost());
        }
        System.out.println("\nMAGAZINES");
        for (Magazine mag : magList)
        {
            System.out.println(mag.getName());
            System.out.println(mag.getCost());
            for (Supplement sup : mag.getSupp())
            {
                System.out.println(sup.getName());
            }
        }     
        System.out.println("\nCUSTOMER DETAILS");
        for (Customer cust : custList)
        {
            System.out.println(cust.getName() + " " + cust.getEmail());
            System.out.println(cust.getClass().getName());
            System.out.println("Supplements interested");
            for (Supplement custSup : cust.getIntSup())
            {
                System.out.println(custSup.getName());
            }
            if (cust instanceof PayingCustomer)
            {
                if (!((PayingCustomer)cust).getRecipt().isEmpty())
                {
                    System.out.println("Items ordered");
                    Map<String, Integer> IDMap = new HashMap<String, Integer>();
                    for(String arrayElement : ((PayingCustomer)cust).getRecipt()) 
                    {
                        if(!IDMap.containsKey(arrayElement)) 
                        {
                            IDMap.put(arrayElement, 1);
                        } 
                        else 
                        {
                            int newCount = IDMap.get(arrayElement) + 1;
                            IDMap.put(arrayElement, newCount);
                        }
                    }
                    for (Map.Entry<String, Integer> info : IDMap.entrySet())
                    {
                        System.out.print(info.getValue() + " ");
                        System.out.println(info.getKey());

                    }
                }      
                System.out.println("Amount due " + ((PayingCustomer)cust).getAmountDue());
                pay = ((PayingCustomer)cust).getPayment();
                if (pay instanceof CreditCard)
                {
                    System.out.println("Credit card" + ((CreditCard) pay).getCSV() + " " + ((CreditCard)pay).getCreditCardNo());
                }
                if (pay instanceof DirectDebit)
                {
                    System.out.println("Direct Debit " + ((DirectDebit)pay).getBSB() + " " + ((DirectDebit)pay).getBankNo());
                }
                if (!((PayingCustomer)cust).getAssocCust().isEmpty())
                {
                    System.out.print("Paying for ");
                    for (Customer aCust : ((PayingCustomer)cust).getAssocCust())
                    {
                        System.out.println(aCust.getName());
                    }
                }  
            }
            if (cust instanceof AssociateCustomer)
                {
                    System.out.println("Assoc Cust who is paying " + ((AssociateCustomer)cust).getWhoIsPaying().getName());
                }
             System.out.println();
        }
        System.out.println("*****END OF INFO DUMP******");
    }

    
}