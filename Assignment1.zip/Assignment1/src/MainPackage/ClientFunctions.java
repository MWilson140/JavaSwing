package MainPackage;
import Customer.*;
import PaymentMethod.*;
import Supplement.*;
import Magazine.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


public class ClientFunctions {

    public static void StudentDetails()
    {
       System.out.println("Mitchell Wilson"); 
       System.out.println("34497163"); 
       System.out.println("Internal"); 
       System.out.println("AZM Chowdhury"); 
       System.out.println("Wednesday 1:30 - 2:30"); 
       System.out.println(""); 
    }
     /**
     * Method for adding a new customer to the customer list.
     * This method is hardcoded for demonstrative purposes
     */ 
     public static void addNewCust(ArrayList<Customer> custList, ArrayList<Supplement> supList)
    {
        System.out.println("adding new customer" + " Mitch (this info is hardcoded)");
        Random rand = new Random();
        PaymentMethod payMethod = new CreditCard(321,5234234);
        ArrayList<Supplement> tempSup = new ArrayList<Supplement>();
        for (int i = 0; i < 2; i ++)
        {
            tempSup.add(supList.get(rand.nextInt(supList.size())));
        }
        Customer tempCust = new PayingCustomer("Mitch", "Mitch@email.com",tempSup,
        payMethod);
        custList.add(tempCust);        
    }

    public static boolean deleteCust(ArrayList<Customer> custList, AssociateCustomer cust)
    {
        PayingCustomer paying = (PayingCustomer)cust.getWhoIsPaying();
        paying.removeAssoc(cust);
        return (custList.remove(cust));
    }

    public static boolean deleteCust(ArrayList<Customer>custList, int n) throws Exception
    {
        System.out.println("deleting customer at position " + n + " " + custList.get(n).getName());
        Customer delCus = new Customer();
        if (custList.size() > n)
        {
            delCus = custList.get(n);
            try 
            {
                if (delCus instanceof PayingCustomer)
               {
                   return (deleteCust(custList, (PayingCustomer)delCus));
               }
               else if (delCus instanceof AssociateCustomer)
               {
                   return (deleteCust(custList, (AssociateCustomer)delCus));
               }
               else 
               {
                   custList.remove(n);
                   return true;
               }   
            }
            catch (Exception e)
            {
                throw new Exception(e.getMessage());
            }
        } 
        return false;
    }

    public static boolean deleteCust(ArrayList<Customer> custList, PayingCustomer cust) throws Exception
    {
        if (((PayingCustomer)cust).getAmountDue() >  0.0)
        {
            throw new Exception("Cannot delete Customer with a balance");         
        }
        else 
        {
            for(Customer AC : cust.getAssoc())
            if (AC instanceof AssociateCustomer)
            {
                if (!converToCust(custList,(AssociateCustomer)AC))
                    {
                        throw new Exception ("error Deleting assoc Customer");
                    }
            }
            return(custList.remove(cust));
        }
        
    }

    public static boolean converToCust(ArrayList<Customer> custList, AssociateCustomer cust) throws Exception
    {
        Customer newCust = new Customer((Customer)cust);
        custList.remove(cust);
        if (!custList.add(newCust))
        {
            throw new Exception("error converting to customer");
        }
        return true;
    }

    public static void readFile(ArrayList<Customer> custList, ArrayList<Supplement> supList, ArrayList<Magazine> magList) throws Exception
    {
         File fileIn = new File("final.txt");
         Scanner reader;
         try
        {
        	 reader = new Scanner (fileIn);
               while (reader.hasNextLine())
               {
                   String data = reader.nextLine();
                   if (!data.isEmpty())
                   {
                       String[] split = data.split(",");
                       //if the line is a supplement
                       if(split[0].equals("1"))
                       {
                           supList.add(Testing.createSupp(split));
                       }
                       //if the line is a magazine
                       if(split[0].equals("2"))
                       {
                           magList.add(Testing.createMag(split,supList));
                       }
                       //if the line is a PayingCustomer
                       if(split[0].equals("6"))
                       {
                           custList.add(Testing.createPCust(split,supList));
                       }
                       //if the line is an AssociateCustomer
                       if(split[0].equals("8"))
                       {
                           custList.add(Testing.createACust(split, supList, custList));
                       }
                   }
               }
               reader.close();
            }
            catch (FileNotFoundException e)
            {
              System.out.println(e.getMessage());
              
              throw new Exception("file did not open");
            }
    }

}
    
