package MainPackage;

import java.util.*;
import Weekly.*;
import Customer.*;
import Supplement.*;
import Magazine.*;


/*
*Title: Assignment1
* Author: Mitchell Wilson 34497163
* date: 9/04/2024
* file name:Mavenproject3.java
* Purpose: Create a magazine with supplements and clients subscribed to the magazine. Each week the program
* will send out the magazine to clients and increase their amount due depending on their interested supplements 
* Assumptions:
* Payment will not be handled by this program
* Only paying customer receive the magazine 
* When a paying customer is removed, the associated customers become base customers
* Paying customers receive the receipt from their associate customers
* A paying customer can have multiple associated customers
* The information is valid coming into the program (not checking validity)
* A customer cannot be removed when they have an amount due
* 
* input conditions:
* The input conditions should follow the template inside the final.txt file in csv format
* where
* 1 is a supplement with a name and price
* 2 is a magazine with a name, price, list supplements(optional)
* 6 is a paying customer with a char for bank(b) or credit(c), name, email, payment details 1, payment details 2, supplements(optional)
* 8 is a assoc customer with a name, email, who is paying (string reference), supplements(optional)
* There are no direct user inputs, everything is handled by the file    
* 
* Ouput
* Infodump - just all the information stored in the system from operations
* Weekly emails - emails containing the email address, name, type of customer and what supplements they received this week
* Month emails - email containing the email address, name, amount due and an itemized receipt.
 */

//C:\Users\zealo\OneDrive\Documents\NetBeansProjects\mavenproject3\target\site\apidocs\assignment1\mavenproject3
public class mainFile {

    public static void main(String[] args) 
    {
        ArrayList<Supplement> suppList = new ArrayList<Supplement>();
        ArrayList<Magazine> magList = new ArrayList<Magazine>();
        ArrayList<Customer> custList = new ArrayList<Customer>();
        try
        {
            ClientFunctions.readFile(custList, suppList, magList);
            Testing.infoDump(suppList, magList, custList);
            Weekly.weekly(custList, magList.get(0));
            Testing.infoDump(suppList, magList, custList);
            Weekly.weekly(custList, magList.get(0));
            Testing.infoDump(suppList, magList, custList);
            Weekly.weekly(custList, magList.get(0));
            Testing.infoDump(suppList, magList, custList);
            Weekly.weekly(custList, magList.get(0));
            Testing.infoDump(suppList, magList, custList);
            Weekly.Monthly(custList);
            Testing.infoDump(suppList, magList, custList);
            ClientFunctions.addNewCust(custList, suppList);
            try
            {
                ClientFunctions.deleteCust(custList,0);
            }
            catch (Exception e)
            {
                   System.out.println(e.getMessage());
            }
                        try
            {
                ClientFunctions.deleteCust(custList,3);
            }
            catch (Exception e)
            {
                   System.out.println(e.getMessage());
            }
            Testing.infoDump(suppList, magList, custList);
            try
            {
                System.out.println("setting dunce balance to 0");
                ((PayingCustomer)custList.get(6)).setAmountDue(0);
                ClientFunctions.deleteCust(custList,6);
            }
            catch (Exception e)
            {
                System.out.println(e.getMessage());
            }
            Testing.infoDump(suppList, magList, custList);
            
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
        ClientFunctions.StudentDetails();
        }
}
