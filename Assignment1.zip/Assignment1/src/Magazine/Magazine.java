
package Magazine;
import Supplement.*;
import java.util.ArrayList;

/**
 *
 * @author Mitchell Wilson
 * Class for handling and storing information on the magazine
 */
public class Magazine {
    private String name;
    private ArrayList <Supplement> MagSupp;
    private float magCost;
    
    public Magazine()
    {}
    Magazine(String s)
    {
        name = s;
    }
    Magazine (ArrayList <Supplement> MS)
    {
        MagSupp = MS;        
    }
    public Magazine (String s, float MG, ArrayList <Supplement> MS)
    {
        name = s; 
        MagSupp = MS;
        magCost = MG;
    }
    
    public float getCost()
    {
        return magCost;
    }
    
    public void setName(String s)
    {
        name = s;
    }
    public void addMagSupp(Supplement sup)
    {
        MagSupp.add(sup);
    }
    public void addMagSuppAL(ArrayList<Supplement> sups)
    {
        MagSupp = sups;
    }
    public ArrayList<Supplement> getSupps()
    {
        return MagSupp;
    }
    public String getName()
    {
        return name;
    }
    
    public ArrayList<Supplement> getSupp()
    {
        return MagSupp;
    }
    
    
}
