package Weekly;
import Customer.*;
import Magazine.*;
//import Supplement.*;
import java.util.ArrayList;
/**
 *
 * @author Mitchell Wilson
 * Methods for weekly and monthly operation of the system
 */
public class Weekly {

    static public void weekly(ArrayList<Customer> custList, Magazine mag)
    {
        System.out.println("***START OF WEEKLY***");
        //for each customer, call their sendEmail method
        for (Customer cust : custList)
        {
            cust.sendEmail(mag);
            if (cust instanceof PayingCustomer)
            {
                ((PayingCustomer)cust).updateAmountDue(mag);
            }
        }
                System.out.println("***END OF WEEKLY***");
    }
    //monthly method for operations
    static public void Monthly(ArrayList<Customer> custList)
    {
                System.out.println("***START OF MONTHLY***");
        //for each customer, if they are a paying customer all their sendRecipt method
        for (Customer cust : custList)
        {
            if (cust instanceof PayingCustomer)
            {
                ((PayingCustomer)cust).sendRecipt();
                
            }
        }
        System.out.println("***END OF MONTHLY***");
    }
    
    
    
}
