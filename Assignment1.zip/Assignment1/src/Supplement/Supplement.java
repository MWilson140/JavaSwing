package Supplement;
/**
 *
 * @author Mitchell Wilson
 * Class for storing supplement information
 */
public class Supplement {
    private String Name;
    private float Cost;
    
    Supplement()
    {    
    }
    Supplement(String s)
    {
        Name = s;
    }
    Supplement(float c)
    {
        Cost = c;
    }
    public Supplement(String s, float c)
    {
        Name = s;
        Cost = c;
    }
    public float getCost()
    {
        return Cost;
    }
    public String getName()
    {
        return Name;
    }
    
    public void setCost(float c)
    {
        Cost = c;
    }
    public void setName (String s)
    {
        Name = s;
    }   
}
